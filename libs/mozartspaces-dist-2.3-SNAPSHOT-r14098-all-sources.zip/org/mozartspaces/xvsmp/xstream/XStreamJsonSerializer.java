/**
 * MozartSpaces - Java implementation of Extensible Virtual Shared Memory (XVSM)
 * Copyright 2009-2013 Space Based Computing Group, eva Kuehn, E185/1, TU Vienna
 * Visit http://www.mozartspaces.org for more information.
 *
 * MozartSpaces is free software: you can redistribute it and/or
 * modify it under the terms of version 3 of the GNU Affero General
 * Public License as published by the Free Software Foundation.
 *
 * MozartSpaces is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General
 * Public License along with MozartSpaces. If not, see
 * <http://www.gnu.org/licenses/>.
 */
package org.mozartspaces.xvsmp.xstream;

import net.jcip.annotations.Immutable;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.json.JettisonMappedXmlDriver;

/**
 * Serializer from and to JSON, uses {@link XStream} with the
 * {@link JettisonMappedXmlDriver}.
 *
 * @author Tobias Doenz
 */
@Immutable
public final class XStreamJsonSerializer extends AbstractXStreamSerializer {

    private final XStream xstream;

    /**
     * Constructs an <code>XStreamJsonSerializer</code>.
     */
    public XStreamJsonSerializer() {
        xstream = new XStream(new JettisonMappedXmlDriver());
        xstream.setMode(XStream.NO_REFERENCES);
        XStreamConfiguration.configure(xstream);
    }

    @Override
    public XStream getXStream() {
        return xstream;
    }

}
